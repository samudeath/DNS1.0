package br.edu.ifg.interf;

import java.rmi.Remote;
import java.rmi.RemoteException;

import br.edu.ifg.model.Mensagem;

public interface InterfaceMensagem extends Remote{
	public void enviarMensagem(Mensagem mensagem) throws RemoteException;
	
}
