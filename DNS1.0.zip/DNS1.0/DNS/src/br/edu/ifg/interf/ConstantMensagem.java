package br.edu.ifg.interf;

public class ConstantMensagem {

	public static final String RMI_ID = "Chat_Server";
	public static final int RMI_PORT = 1101;
}
