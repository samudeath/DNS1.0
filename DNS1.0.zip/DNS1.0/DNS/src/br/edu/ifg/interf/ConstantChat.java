package br.edu.ifg.interf;

public class ConstantChat {
	
	public static final String RMI_ID = "Chat_Server";
	public static final int RMI_PORT = 1100;

}
