package br.edu.ifg.model;

import java.io.Serializable;

public class Mensagem implements Serializable{

	private static final long serialVersionUID = 1L;
	private String conteudo;
	private String remetente;
	
	public String getConteudo() {
		return conteudo;
	}
	
	public void setConteudo(String conteudo) {
		this.conteudo = conteudo;
	}
	
	public String getRemetente() {
		return remetente;
	}

	public void setRemetente(String remetente) {
		this.remetente = remetente;
	}

	public String toString() {
		return remetente +": " + conteudo;
		}
	

}
