package br.edu.ifg.cliente;

import java.net.UnknownHostException;
import java.rmi.RemoteException;

import javax.swing.JOptionPane;

public class ChatMain {

	/**
	 * Metodo main
	 * @param args
	 * @throws UnknownHostException
	 * @throws RemoteException 
	 */
	public static void main(String[] args) throws UnknownHostException, RemoteException {
		
		String nick = JOptionPane.showInputDialog("Digite seu nome:");
		
		Chat chat = new Chat(nick);
		chat.lookupDNS();
		String nickAmigo = JOptionPane.showInputDialog("Digite o nick do seu amigo:");
		String ipAmigo = chat.obterIpAmigo(nickAmigo);
		System.out.println("O ip do seu amigo �: " +ipAmigo);
		
		
		
	}
	
}
