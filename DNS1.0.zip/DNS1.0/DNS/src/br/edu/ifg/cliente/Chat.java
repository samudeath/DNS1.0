package br.edu.ifg.cliente;

import br.edu.ifg.interf.*;
import br.edu.ifg.model.Mensagem;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Chat {
Mensagem mensagem = new Mensagem();
	private String nick;
	InterfaceDNS remote;
	InterfaceDNS remoteChat;

	public Chat(String nick) {
		this.nick = nick;
	}

	/**
	 * Metodo para realizacao de lookup no servidor DNS
	 */
	public void lookupDNS() {

		try {

			Registry registry = LocateRegistry.getRegistry("localhost", ConstantDNS.RMI_PORT);
			remote = (InterfaceDNS) registry.lookup(ConstantDNS.RMI_ID);
			String ip = obtemMeuIP();
			remote.autentica(nick, ip);
			
			

		} catch (Exception e) {
			System.err.println("Client exception: " + e.toString());
			e.printStackTrace();
		}

	}
	
	/**
	 * Metodo para realizar lookup no chat
	 */
	public void lookupChat() {
		
		try {

			Registry registry = LocateRegistry.getRegistry("localhost", ConstantChat.RMI_PORT);
			remoteChat = (InterfaceDNS) registry.lookup(ConstantChat.RMI_ID);


		} catch (Exception e) {
			System.err.println("Client exception: " + e.toString());
			e.printStackTrace();
		}
		
	}

	/**
	 * Metodo para obtencao do meu endereco IP
	 * 
	 * @return
	 * @throws UnknownHostException
	 */
	public String obtemMeuIP() throws UnknownHostException {
		InetAddress ip = InetAddress.getLocalHost();
		String hostname = ip.getHostAddress();
		return hostname;
	}

	public String obterIpAmigo(String nickAmigo) throws RemoteException {
		String ipAmigo = remote.obterIP(nickAmigo);
		return ipAmigo;
	}
	
	

}